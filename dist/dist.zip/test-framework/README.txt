The Solr test-framework products base classes and utility classes for 
writting JUnit tests excercising Solr functionality.

This test framework relies on the lucene components found in in the 
./lucene-libs/ directory, as well as the third-party libraries found 
in the ./lib directory.
